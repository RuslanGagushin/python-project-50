from gendiff.modules.parser_args import parser_args


def main():
    args = parser_args()


if __name__ == "__main__":
    main()
